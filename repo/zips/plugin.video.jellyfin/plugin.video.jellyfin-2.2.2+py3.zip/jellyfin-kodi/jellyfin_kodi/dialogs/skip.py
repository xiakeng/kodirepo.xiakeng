# -*- coding: utf-8 -*-

import xbmc
import xbmcgui

from ..helper import LazyLogger, translate

LOG = LazyLogger(__name__)

# Action IDs
ACTION_PARENT_DIR = 9
ACTION_PREVIOUS_MENU = 10
ACTION_BACK = 92
ACTION_NAV_BACK = 92

# Control IDs
SKIP_BUTTON = 3012
DISMISS_BUTTON = 3013

# Localized short label IDs for known segment types
SEGMENT_LABEL_IDS = {
    "Introduction": 33252,
    "Credits": 33253,
    "Recap": 33254,
    "Preview": 33255,
    "Commercial": 33259,
}


def get_player_art():
    for art in [
        "thumb",
        "landscape",
        "fanart",
    ]:
        # Always returns a string.
        artwork = xbmc.getInfoLabel("Player.Art(%s)" % art)
        # actions.py uses a whitespace sentinel for missing artwork.
        if artwork.strip():
            return artwork
    return ""


class SkipDialog(xbmcgui.WindowXMLDialog):
    """
    OSD overlay dialog for skipping intro/outro segments.

    Based on service.upnext popup pattern for reliable non-modal display.
    """

    def __init__(self, *args, **kwargs):
        self._segment_type = kwargs.pop("segment_type", None)
        self._duration = kwargs.pop("duration", 0)

        # State flags
        self.skip_requested = False
        self.cancel_requested = False

        # Set properties before super().__init__ to avoid flicker
        # (like service.upnext does in set_info)

        xbmcgui.WindowXMLDialog.__init__(self, *args)

    def set_skip_info(self, segment_type, duration):
        """Set the skip segment information."""
        self._segment_type = segment_type
        self._duration = duration

        # Format duration text
        minutes = int(duration // 60)
        seconds = int(duration % 60)
        if minutes > 0:
            duration_text = translate(33264).format(minutes, seconds)
        else:
            duration_text = translate(33265).format(seconds)

        segment_label = translate(SEGMENT_LABEL_IDS[segment_type])

        skip_detail = "{} • {}".format(segment_label, duration_text)

        # Use setProperty so detail text is available to the skin.
        self.setProperty("skip_detail", skip_detail)
        self.setProperty("segment_type", segment_type or "")
        self.setProperty("duration", duration_text)
        self.setProperty("segment_image", get_player_art())

        LOG.debug(
            "SkipDialog: set_skip_info segment=%s, detail=%s", segment_type, skip_detail
        )

    def onAction(self, action):
        """Handle user actions."""
        action_id = action.getId()
        LOG.debug("SkipDialog.onAction: action_id=%s", action_id)

        if action_id in (
            ACTION_BACK,
            ACTION_PARENT_DIR,
            ACTION_PREVIOUS_MENU,
            ACTION_NAV_BACK,
        ):
            self.cancel_requested = True
            self.close()

    def onClick(self, control_id):
        """Handle control clicks."""
        LOG.debug("SkipDialog.onClick: control_id=%s", control_id)

        if control_id == SKIP_BUTTON:
            LOG.debug("Skip button clicked for %s", self._segment_type)
            self.skip_requested = True
            self.close()
        elif control_id == DISMISS_BUTTON:
            LOG.debug("Dismiss button clicked")
            self.cancel_requested = True
            self.close()

    def is_skip(self):
        """Return whether the user requested to skip."""
        return self.skip_requested

    def is_cancel(self):
        """Return whether the user cancelled."""
        return self.cancel_requested
